import AppNavigator from 'BiddingApp/app/config/router';
export default AppNavigator;
