
import GlobalConst from './GlobalConst';
import Icon from 'react-native-vector-icons/FontAwesome';
import ModalComponent from '../components/others/ModalComponent';


export {
        GlobalConst, Icon, ModalComponent
      };
