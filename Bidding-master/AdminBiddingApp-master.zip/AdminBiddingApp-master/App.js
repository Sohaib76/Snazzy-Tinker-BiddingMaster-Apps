import AppNavigator from "./app/config/router";
export default AppNavigator;
